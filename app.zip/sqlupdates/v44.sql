UPDATE `business_settings` SET `value` = '4.4' WHERE `business_settings`.`type` = 'current_version';

COMMIT;
